<div class="modal fade" id="editmodal-<?php echo e($utang->id); ?>" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    Update
                    Utang Teman
                </h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="user" id="<?php echo e($utang->id); ?>form" method="POST"
                    action="<?php echo e(route('utangtemans.update', $utang)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-user " name="nama"
                            value="<?php echo e(old('nama') ?? $utang->nama); ?>" required aria-describedby="emailHelp"
                            placeholder="Utang ke Siapa">
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control form-control-user " name="jumlah" disabled
                            value="<?php echo e($utang->jumlah); ?>" x aria-describedby="emailHelp" placeholder="Jumlah Utang">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-user " name="keterangan"
                            value="<?php echo e(old('keterangan') ?? $utang->keterangan); ?>" aria-describedby="emailHelp"
                            placeholder="Keterangan">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary"
                    onclick="event.preventDefault();document.getElementById('<?php echo e($utang->id); ?>form').submit();">Edit</a>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\myfinance-app\resources\views/utangteman/edit.blade.php ENDPATH**/ ?>