<div class="limiter">
    <div class="container-table100">
        <div class="wrap-table100">
            <div class="table">

                <div class="row header">
                    <div class="cell">
                        Full Name
                    </div>
                    <div class="cell">
                        Age
                    </div>
                    <div class="cell">
                        Job Title
                    </div>
                    <div class="cell">
                        Location
                    </div>
                </div>

                <div class="row">
                    <div class="cell" data-title="Full Name">
                        Vincent Williamson
                    </div>
                    <div class="cell" data-title="Age">
                        31
                    </div>
                    <div class="cell" data-title="Job Title">
                        android Developer
                    </div>
                    <div class="cell" data-title="Location">
                        Washington
                    </div>
                </div>

                <div class="row">
                    <div class="cell" data-title="Full Name">
                        Joseph Smith
                    </div>
                    <div class="cell" data-title="Age">
                        27
                    </div>
                    <div class="cell" data-title="Job Title">
                        Project Manager
                    </div>
                    <div class="cell" data-title="Location">
                        Somerville, MA
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>" />

<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\myfinance-app\resources\views/layouts/table.blade.php ENDPATH**/ ?>