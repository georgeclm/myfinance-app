<?php $__env->startSection('content'); ?>
    <div id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-2 text-gray-800">Utang Anda</h1>
                    <a href="#" data-toggle="modal" data-target="#addRekening"
                        class="d-sm-inline-block btn btn-sm btn-danger shadow-sm"><i
                            class="fas fa-download fa-sm text-white-50"></i> Tambah Utang Anda</a>
                </div>
                <div class="row">
                    <?php if(!auth()->user()->utangs->isEmpty()): ?>

                        <!-- Income (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                Total Utang</div>
                                            <div class="h5 mb-0 font-weight-bold text-danger">Rp.
                                                <?php echo e(number_format(Auth::user()->totalutang())); ?>

                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-money-bill-wave fa-2x text-danger"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-lg-6">
                            <div class="card mb-4 py-3 border-left-success">
                                <div class="card-body">
                                    Tumben Anda Tidak Ngutang
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Utang</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Utang ke Siapa</th>
                                        <th>Jumlah</th>
                                        <th>Keterangan</th>
                                        <th>Tanggal</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->utangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php echo $__env->make('utang.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <tr>
                                            <td><?php echo e($utang->nama); ?></td>
                                            <td>Rp. <?php echo e(number_format($utang->jumlah)); ?></td>
                                            <td><?php echo e($utang->keterangan); ?></td>
                                            <td><?php echo e($utang->created_at->format('l j F Y')); ?></td>
                                            <td> <button data-toggle="modal" data-target="#editmodal-<?php echo e($utang->id); ?>"
                                                    type="button" class="btn btn-info btn-circle">
                                                    <i class="fas fa-info-circle"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="5" class="text-center">Anda Tidak Punya Utang</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->
    <?php echo $__env->make('utang.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfinance-app\resources\views/utang/index.blade.php ENDPATH**/ ?>