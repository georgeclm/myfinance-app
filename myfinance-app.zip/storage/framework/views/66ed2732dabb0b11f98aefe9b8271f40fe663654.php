<div class="modal fade" id="editmodal-<?php echo e($rekening->id); ?>" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    Update
                    Rekening
                </h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="user" id="<?php echo e($rekening->id); ?>form" method="POST"
                    action="<?php echo e(route('rekenings.update', $rekening)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <select class="form-control form-control-user form-block" style="padding: 0.5rem !important"
                            aria-describedby="emailHelp" disabled>
                            <?php $__currentLoopData = $jeniss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jenis->id); ?>" <?php if($jenis->id == $rekening->jenis_id): ?> selected <?php endif; ?>>
                                    <?php echo e($jenis->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-user " name="nama_akune"
                            value="<?php echo e(old('nama_akune') ?? $rekening->nama_akun); ?>" required
                            aria-describedby="emailHelp" placeholder="Nama Akun">
                    </div>
                    <?php if($rekening->jenis_id != 1): ?>
                        <div class="form-group">
                            <input type="text" class="form-control form-control-user " name="nama_banke"
                                value="<?php echo e(old('nama_banke') ?? $rekening->nama_bank); ?>" required
                                aria-describedby="emailHelp" placeholder="Nama Bank">
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <input type="number" class="form-control form-control-user " name="saldo_sekarange"
                            value="<?php echo e(old('saldo_sekarange') ?? $rekening->saldo_sekarang); ?>" disabled
                            aria-describedby="emailHelp" placeholder="Saldo Sekarang">
                    </div>
                    <?php if($rekening->jenis_id == 2): ?>
                        <div class="form-group">
                            <input type="number" class="form-control form-control-user " name="saldo_mengendape"
                                value="<?php echo e(old('saldo_mengendape') ?? $rekening->saldo_mengendap); ?>"
                                aria-describedby="emailHelp" placeholder="Saldo Mengendap">
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-user " name="keterangane"
                            value="<?php echo e(old('keterangane') ?? $rekening->keterangan); ?>" aria-describedby="emailHelp"
                            placeholder="Keterangan">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger" href="<?php echo e(route('rekenings.destroy', $rekening)); ?>">Delete</a>
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary"
                    onclick="event.preventDefault();document.getElementById('<?php echo e($rekening->id); ?>form').submit();">Edit</a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\myfinance-app\resources\views/rekening/edit.blade.php ENDPATH**/ ?>