<?php $__env->startSection('content'); ?>
    <div id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-2 text-gray-800">Catatan Keuangan</h1>
                    <?php if(!auth()->user()->rekenings->isEmpty()): ?>
                        <a href="#" data-toggle="modal" data-target="#addRekening"
                            class="d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Tambah Transaksi</a>
                    <?php endif; ?>


                </div>
                <div class="row">
                    <?php echo $__env->make('layouts.partials.income', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('layouts.partials.spending', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('layouts.partials.balance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card shadow h-100 py-2 border-bottom-info">
                            <div class="h3 fw-bold text-info card-body">
                                <form action="" method="get">

                                    <select class="form-control form-control-user" name="q" onchange="this.form.submit()">
                                        <option value="" selected disabled hidden>This Month</option>
                                        <option value="1" <?php if(request()->q == 1): ?> selected <?php endif; ?>>Previous Month</option>
                                        <option value="2" <?php if(request()->q == 2): ?> selected <?php endif; ?>>All</option>

                                    </select>

                                </form>
                                
                            </div>
                        </div>
                    </div>
                    <?php if(auth()->user()->rekenings->isEmpty()): ?>
                        <div class="col-lg-6">
                            <div class="card mb-4 py-3 border-left-success">
                                <div class="card-body">
                                    Buat Rekening Dulu Sebelum Mencatat Keuangan
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php $__currentLoopData = $jenisuangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisuang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"><?php echo e($jenisuang->nama); ?></h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <div class="wrap-table100 " id="thetable">
                                    <div class="table">
                                        <div class="row header">
                                            <div class="cell ">
                                                Jumlah
                                            </div>
                                            <?php if(in_array($jenisuang->id, [4, 5])): ?>
                                                <div class="cell">
                                                    Nama Utang
                                                </div>
                                            <?php endif; ?>
                                            <?php if(in_array($jenisuang->id, [1, 2])): ?>

                                                <div class="cell">
                                                    Kategori
                                                </div>
                                            <?php endif; ?>
                                            <div class="cell">
                                                Akun
                                            </div>
                                            <?php if($jenisuang->id == 3): ?>

                                                <div class="cell">
                                                    Akun Tujuan
                                                </div>
                                            <?php endif; ?>
                                            <div class="cell">
                                                Keterangan
                                            </div>
                                            <div class="cell">
                                                Tanggal
                                            </div>
                                        </div>

                                        <?php $__empty_1 = true; $__currentLoopData = $jenisuang->user_transactions->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="row">
                                                <div class="cell <?php echo e($jenisuang->textColor()); ?>" data-title="Jumlah">
                                                    Rp. <?php echo e(number_format($transaction->jumlah)); ?>

                                                </div>
                                                <?php if($transaction->utang_id): ?>
                                                    <div class="cell" data-title="Nama Utang">
                                                        <?php echo e($transaction->utang->keterangan ?? $transaction->utang->nama); ?>

                                                    </div>
                                                <?php endif; ?>
                                                <?php if($transaction->utangteman_id): ?>
                                                    <div class="cell" data-title="Nama Utang">
                                                        <?php echo e($transaction->utangteman->keterangan ?? $transaction->utangteman->nama); ?>

                                                    </div>
                                                <?php endif; ?>
                                                <?php if($jenisuang->id == 1): ?>
                                                    <div class="cell" data-title="Kategori">
                                                        <?php echo e($transaction->category_masuk->nama); ?>

                                                    </div>
                                                <?php endif; ?>
                                                <?php if($jenisuang->id == 2): ?>
                                                    <div class="cell" data-title="Kategori">
                                                        <?php echo e($transaction->category->nama); ?>

                                                    </div>
                                                <?php endif; ?>
                                                <div class="cell" data-title="Akun">
                                                    <?php echo e($transaction->rekening->nama_akun); ?>

                                                </div>
                                                <?php if($jenisuang->id == 3): ?>
                                                    <div class="cell" data-title="Akun Tujuan">
                                                        <?php echo e($transaction->rekening_tujuan->nama_akun); ?>

                                                    </div>
                                                <?php endif; ?>
                                                <div class="cell" data-title="Keterangan">
                                                    <?php echo e($transaction->keterangan); ?>

                                                </div>
                                                <div class="cell" data-title="Tanggal">
                                                    <?php echo e($transaction->created_at->format('l j F Y')); ?>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <table class="table table-bordered" width="100%" cellspacing="0" id="bigtable">
                                    <thead>
                                        <tr class="<?php echo e($jenisuang->color()); ?> text-light">
                                            <th>Jumlah</th>
                                            <?php if(in_array($jenisuang->id, [4, 5])): ?>
                                                <th>Nama Utang</th>
                                            <?php endif; ?>

                                            <?php if(in_array($jenisuang->id, [1, 2])): ?>
                                                <th>Kategori</th>
                                            <?php endif; ?>
                                            <th>Akun</th>
                                            <?php if($jenisuang->id == 3): ?>
                                                <th>Akun Tujuan</th>
                                            <?php endif; ?>
                                            <th>Keterangan</th>
                                            <th>Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $jenisuang->user_transactions->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td>Rp. <?php echo e(number_format($transaction->jumlah)); ?></td>
                                                <?php if($transaction->utang_id): ?>
                                                    <td><?php echo e($transaction->utang->keterangan ?? $transaction->utang->nama); ?>

                                                    </td>
                                                <?php endif; ?>
                                                <?php if($transaction->utangteman_id): ?>
                                                    <td><?php echo e($transaction->utangteman->keterangan ?? $transaction->utangteman->nama); ?>

                                                    </td>
                                                <?php endif; ?>
                                                <?php if($jenisuang->id == 1): ?>
                                                    <td><?php echo e($transaction->category_masuk->nama); ?></td>
                                                <?php endif; ?>
                                                <?php if($jenisuang->id == 2): ?>
                                                    <td><?php echo e($transaction->category->nama); ?></td>
                                                <?php endif; ?>
                                                <td><?php echo e($transaction->rekening->nama_akun); ?></td>
                                                <?php if($transaction->rekening_tujuan): ?>
                                                    <td><?php echo e($transaction->rekening_tujuan->nama_akun); ?></td>
                                                <?php endif; ?>
                                                <td><?php echo e($transaction->keterangan); ?></td>
                                                <td><?php echo e($transaction->created_at->format('l j F Y')); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="5" class="text-center">Transaksi Kosong</td>
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                </table>
                                <?php if($jenisuang->user_transactions->count() > 5): ?>
                                    <?php if(request()->has('q')): ?>
                                        <div class="text-end mt-3"><a
                                                href="<?php echo e(route('jenisuangs.show', ['q' => request()->q, $jenisuang])); ?>">Show
                                                All</a></div>
                                    <?php else: ?>
                                        <div class="text-end mt-3"><a
                                                href="<?php echo e(route('jenisuangs.show', $jenisuang)); ?>">Show
                                                All</a></div>

                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->make('transaction.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfinance-app\resources\views/transaction/index.blade.php ENDPATH**/ ?>