<?php $__env->startSection('content'); ?>
    <div id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-2 text-gray-800"><?php echo e($jenisuang->nama); ?></h1>
                    
                </div>
                <div class="row">
                    <?php echo $__env->make('layouts.partials.income', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('layouts.partials.spending', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('layouts.partials.balance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card shadow h-100 py-2 border-bottom-info">
                            <div class="h3 fw-bold text-info card-body">
                                <form action="" method="get">
                                    <?php if(request()->has('search')): ?>
                                        <input type="hidden" name="search" value="<?php echo e(request()->search); ?>">
                                    <?php endif; ?>
                                    <?php if(request()->has('search2')): ?>
                                        <input type="hidden" name="search2" value="<?php echo e(request()->search2); ?>">
                                    <?php endif; ?>
                                    <select class="form-control form-control-user" name="q" onchange="this.form.submit()">
                                        <option value="" selected disabled hidden>This Month</option>
                                        <option value="1" <?php if(request()->q == 1): ?> selected <?php endif; ?>>Previous Month</option>
                                        <option value="2" <?php if(request()->q == 2): ?> selected <?php endif; ?>>All</option>

                                    </select>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php if(auth()->user()->rekenings->isEmpty()): ?>
                        <div class="col-lg-6">
                            <div class="card mb-4 py-3 border-left-success">
                                <div class="card-body">
                                    Buat Rekening Dulu Sebelum Mencatat Keuangan
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <div class="row align-items-baseline">
                            <div class="col-md-5">
                                <h6 class="font-weight-bold text-primary"><?php echo e($jenisuang->nama); ?></h6>
                            </div>
                            <?php if($jenisuang->id == 2): ?>
                                <div class="col-md-5">
                                    <h6 class="font-weight-bold text-danger">Rp.
                                        <?php echo e(number_format(!request()->has('search') ? $jenisuang->categoriesTotal() : $jenisuang->categoryTotal(request()->search))); ?>

                                    </h6>
                                </div>
                                <div class="col-md-2">
                                    <form action="" method="get">
                                        <?php if(request()->has('q')): ?>
                                            <input type="hidden" name="q" value="<?php echo e(request()->q); ?>">
                                        <?php endif; ?>
                                        <select class="form-control form-control-user" name="search"
                                            onchange="this.form.submit()">
                                            <option value="" selected disabled hidden>Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php if(request()->search == $category->id): ?> selected <?php endif; ?>><?php echo e($category->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </form>
                                </div>
                            <?php endif; ?>
                            <?php if($jenisuang->id == 1): ?>
                                <div class="col-md-5">
                                    <h6 class="font-weight-bold text-danger">Rp.
                                        <?php echo e(number_format(!request()->has('search2') ? $jenisuang->categoryMasuksTotal() : $jenisuang->categoryMasukTotal(request()->search2))); ?>

                                    </h6>
                                </div>
                                <div class="col-md-2">
                                    <form action="" method="get">
                                        <?php if(request()->has('q')): ?>
                                            <input type="hidden" name="q" value="<?php echo e(request()->q); ?>">
                                        <?php endif; ?>
                                        <select class="form-control form-control-user" name="search2"
                                            onchange="this.form.submit()">
                                            <option value="" selected disabled hidden>Category</option>
                                            <?php $__currentLoopData = App\Models\CategoryMasuk::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php if(request()->search2 == $category->id): ?> selected <?php endif; ?>><?php echo e($category->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <div class="wrap-table100 " id="thetable">
                                <div class="table">
                                    <div class="row header">
                                        <div class="cell ">
                                            Jumlah
                                        </div>
                                        <?php if(in_array($jenisuang->id, [4, 5])): ?>
                                            <div class="cell">
                                                Nama Utang
                                            </div>
                                        <?php endif; ?>
                                        <?php if(in_array($jenisuang->id, [1, 2])): ?>
                                            <div class="cell">
                                                Kategori
                                            </div>
                                        <?php endif; ?>
                                        <div class="cell">
                                            Akun
                                        </div>
                                        <?php if($jenisuang->id == 3): ?>
                                            <div class="cell">
                                                Akun Tujuan
                                            </div>
                                        <?php endif; ?>
                                        <div class="cell">
                                            Keterangan
                                        </div>
                                        <div class="cell">
                                            Tanggal
                                        </div>
                                    </div>
                                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="row">
                                            <div class="cell <?php echo e($jenisuang->textColor()); ?>" data-title="Jumlah">
                                                Rp. <?php echo e(number_format($transaction->jumlah)); ?>

                                            </div>
                                            <?php if($transaction->utang_id): ?>
                                                <div class="cell" data-title="Nama Utang">
                                                    <?php echo e($transaction->utang->keterangan ?? $transaction->utang->nama); ?>

                                                </div>
                                            <?php endif; ?>
                                            <?php if($transaction->utangteman_id): ?>
                                                <div class="cell" data-title="Nama Utang">
                                                    <?php echo e($transaction->utangteman->keterangan ?? $transaction->utangteman->nama); ?>

                                                </div>
                                            <?php endif; ?>
                                            <?php if($jenisuang->id == 1): ?>
                                                <div class="cell" data-title="Kategori">
                                                    <?php echo e($transaction->category_masuk->nama); ?>

                                                </div>
                                            <?php endif; ?>
                                            <?php if($jenisuang->id == 2): ?>
                                                <div class="cell" data-title="Kategori">
                                                    <?php echo e($transaction->category->nama); ?>

                                                </div>
                                            <?php endif; ?>
                                            <div class="cell" data-title="Akun">
                                                <?php echo e($transaction->rekening->nama_akun); ?>

                                            </div>
                                            <?php if($jenisuang->id == 3): ?>
                                                <div class="cell" data-title="Akun Tujuan">
                                                    <?php echo e($transaction->rekening_tujuan->nama_akun); ?>

                                                </div>
                                            <?php endif; ?>
                                            <div class="cell" data-title="Keterangan">
                                                <?php echo e($transaction->keterangan); ?>

                                            </div>
                                            <div class="cell" data-title="Tanggal">
                                                <?php echo e($transaction->created_at->format('l j F Y')); ?>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <table class="table table-bordered" width="100%" cellspacing="0" id="bigtable">
                                <thead>
                                    <tr class="<?php echo e($jenisuang->color()); ?> text-light">
                                        <th>Jumlah</th>
                                        <?php if(in_array($jenisuang->id, [4, 5])): ?>
                                            <th>Nama Utang</th>
                                        <?php endif; ?>
                                        <?php if(in_array($jenisuang->id, [1, 2])): ?>
                                            <th>Kategori</th>
                                        <?php endif; ?>
                                        <th>Akun</th>
                                        <?php if($jenisuang->id == 3): ?>
                                            <th>Akun Tujuan</th>
                                        <?php endif; ?>
                                        <th>Keterangan</th>
                                        <th>Tanggal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>Rp. <?php echo e(number_format($transaction->jumlah)); ?></td>
                                            <?php if($transaction->utang_id): ?>
                                                <td><?php echo e($transaction->utang->keterangan ?? $transaction->utang->nama); ?>

                                                </td>
                                            <?php endif; ?>
                                            <?php if($transaction->utangteman_id): ?>
                                                <td><?php echo e($transaction->utangteman->keterangan ?? $transaction->utangteman->nama); ?>

                                                </td>
                                            <?php endif; ?>
                                            <?php if($jenisuang->id == 1): ?>
                                                <td><?php echo e($transaction->category_masuk->nama); ?></td>
                                            <?php endif; ?>
                                            <?php if($jenisuang->id == 2): ?>
                                                <td><?php echo e($transaction->category->nama); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($transaction->rekening->nama_akun); ?></td>
                                            <?php if($transaction->rekening_tujuan): ?>
                                                <td><?php echo e($transaction->rekening_tujuan->nama_akun); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($transaction->keterangan); ?></td>
                                            <td><?php echo e($transaction->created_at->format('l j F Y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="5" class="text-center">Transaksi Kosong</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- End of Main Content -->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfinance-app\resources\views/jenisuang/detail.blade.php ENDPATH**/ ?>