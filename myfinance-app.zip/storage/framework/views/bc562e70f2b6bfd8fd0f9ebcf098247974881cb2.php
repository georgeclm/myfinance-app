<?php $__env->startSection('content'); ?>
    <div id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-2 text-gray-800">Settings</h1>
                </div>
                <div class="row">

                    <div class="col-lg-6">
                        <!-- Dropdown Card Example -->
                        <div class="card shadow mb-4">
                            <!-- Card Header - Dropdown -->
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold text-danger">Categories Uang Keluar</h6>
                                <a href="#" data-toggle="modal" data-target="#addCategory">
                                    <i class="fas fa-plus fa-sm fa-fw text-danger"></i>
                                </a>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <ul class="list-group">
                                    <?php $__currentLoopData = App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex align-items-center">
                                            <div class="w-100 text-danger">
                                                <i
                                                    class="fas <?php echo e($category->icon()); ?> text-danger mx-2"></i><?php echo e($category->nama); ?>

                                            </div>
                                            <?php if($category->created_at): ?>
                                                <a href="<?php echo e(route('categories.remove', $category)); ?>">
                                                    <span class="badge badge-danger badge-pill text-end">x</span></a>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold text-success">Categories Uang Masuk</h6>
                                <a href="#" data-toggle="modal" data-target="#addCategoryMasuk">
                                    <i class="fas fa-plus fa-sm fa-fw text-success"></i>
                                </a>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <ul class="list-group">
                                    <?php $__currentLoopData = App\Models\CategoryMasuk::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex align-items-center">
                                            <div class="w-100 text-success">
                                                <i
                                                    class="fas <?php echo e($category->icon()); ?> text-success mx-2"></i><?php echo e($category->nama); ?>

                                            </div>
                                            <?php if($category->created_at): ?>
                                                <a href="<?php echo e(route('category_masuks.remove', $category)); ?>">
                                                    <span class="badge badge-success badge-pill">x</span></a>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('settings.createCategory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('settings.createCategoryMasuk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Page Wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfinance-app\resources\views/settings/settings.blade.php ENDPATH**/ ?>