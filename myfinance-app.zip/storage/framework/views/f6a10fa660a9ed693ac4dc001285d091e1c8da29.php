<?php $__env->startSection('content'); ?>
    <div id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    
                </div>
                <!-- Content Row -->
                <div class="row">
                    <?php echo $__env->make('layouts.partials.income', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('layouts.partials.spending', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('layouts.partials.balance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('layouts.partials.totalbalance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <!-- Content Row -->
                <!-- Area Chart -->
                
                
                <div class="row">
                    <?php if(auth()->user()->uangkeluar() != 0): ?>
                        <!-- Content Column -->
                        <div class="col-lg-6 mb-4">
                            <!-- Project Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-danger">Pengeluaran
                                        Bulan <?php echo e(now()->format('F')); ?></h6>
                                </div>
                                <div class="card-body">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($category->persen() != 0): ?>
                                            <h4 class="small font-weight-bold"><?php echo e($category->nama); ?><span
                                                    class="float-right"><?php echo e($category->persen()); ?>%</span>
                                            </h4>
                                            <div class="progress mb-4">
                                                <div class="progress-bar <?php echo e($category->bgColor()); ?>" role="progressbar"
                                                    style="width: <?php echo e($category->persen()); ?>%"
                                                    aria-valuenow="<?php echo e($category->persen()); ?>" aria-valuemin="0"
                                                    aria-valuemax="100">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-lg-6">
                            <div class="card mb-4 py-3 border-left-success">
                                <div class="card-body">
                                    Mulai Buat Rekening Lalu Coba Transaksi
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(auth()->user()->uangmasuk() != 0): ?>
                        <!-- Content Column -->
                        <div class="col-lg-6 mb-4">
                            <!-- Project Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-success">Pemasukan
                                        Bulan <?php echo e(now()->format('F')); ?></h6>
                                </div>
                                <div class="card-body">
                                    <?php $__currentLoopData = App\Models\CategoryMasuk::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($category->persen() != 0): ?>
                                            <h4 class="small font-weight-bold"><?php echo e($category->nama); ?><span
                                                    class="float-right"><?php echo e($category->persen()); ?>%</span>
                                            </h4>
                                            <div class="progress mb-4">
                                                <div class="progress-bar <?php echo e($category->bgColor()); ?>" role="progressbar"
                                                    style="width: <?php echo e($category->persen()); ?>%"
                                                    aria-valuenow="<?php echo e($category->persen()); ?>" aria-valuemin="0"
                                                    aria-valuemax="100">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                        </div>

                    <?php endif; ?>
                </div>

                <!-- /.container-fluid -->
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfinance-app\resources\views/home.blade.php ENDPATH**/ ?>